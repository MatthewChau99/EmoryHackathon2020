package com.example.Hackathon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackathonApplicationTests {

	@Test
	void contextLoads() {
	}

}
